# instalador Scriptssh 
```
apt-get update -y; apt-get upgrade -y;wget https://raw.githubusercontent.com/modderajuda/donomodderajuda/main/Plus ; chmod 777 Plus ; ./Plus
```

# Definir/Alterar senha root
```
bash <(wget -qO- raw.githubusercontent.com/modderajuda/donomodderajuda/main/senharoot.ssh)
```
